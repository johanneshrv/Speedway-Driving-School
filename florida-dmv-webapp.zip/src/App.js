import React, { useState } from 'react';

const questions = {
  en: Array.from({ length: 50 }, (_, i) => ({
    id: i + 1,
    question: `Sample Question ${i + 1} in English?`,
    options: [
      `Option A for Q${i + 1}`,
      `Option B for Q${i + 1}`,
      `Option C for Q${i + 1}`
    ],
    correctIndex: 1,
    explanation: `Explanation for English Q${i + 1}`
  })),
  es: Array.from({ length: 50 }, (_, i) => ({
    id: i + 1,
    question: `Pregunta de ejemplo ${i + 1} en español?`,
    options: [
      `Opción A para P${i + 1}`,
      `Opción B para P${i + 1}`,
      `Opción C para P${i + 1}`
    ],
    correctIndex: 1,
    explanation: `Explicación para la pregunta ${i + 1} en español`
  }))
};

export default function DMVTestApp() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [language, setLanguage] = useState('es');

  const question = questions[language][currentQuestionIndex];

  function handleAnswer(index) {
    if (!isAnswered) {
      setSelectedIndex(index);
      setIsAnswered(true);
    }
  }

  function nextQuestion() {
    setSelectedIndex(null);
    setIsAnswered(false);
    setCurrentQuestionIndex((prev) => Math.min(prev + 1, questions[language].length - 1));
  }

  function toggleLanguage() {
    setLanguage((prev) => (prev === 'es' ? 'en' : 'es'));
    setCurrentQuestionIndex(0);
    setSelectedIndex(null);
    setIsAnswered(false);
  }

  const labels = {
    es: {
      title: 'DMV FLORIDA',
      questionCount: `Pregunta ${currentQuestionIndex + 1} de ${questions[language].length}`,
      correct: 'Correcto',
      incorrect: 'Incorrecto',
      next: 'Siguiente Pregunta',
      toggle: 'Cambiar a Inglés'
    },
    en: {
      title: 'FLORIDA DMV',
      questionCount: `Question ${currentQuestionIndex + 1} of ${questions[language].length}`,
      correct: 'Correct',
      incorrect: 'Incorrect',
      next: 'Next Question',
      toggle: 'Switch to Spanish'
    }
  };

  const text = labels[language];

  return (
    <div className="min-h-screen bg-[#001f3f] text-white p-8 font-sans">
      <div className="max-w-xl mx-auto bg-[#001f3f]">
        <div className="flex justify-between items-center mb-4">
          <h1 className="text-3xl text-yellow-400 font-bold">{text.title}</h1>
          <button
            onClick={toggleLanguage}
            className="text-sm bg-yellow-400 text-black px-3 py-1 rounded hover:bg-yellow-300"
          >
            {text.toggle}
          </button>
        </div>
        <div className="text-lg mb-6">{text.questionCount}</div>
        <div className="text-2xl font-semibold mb-6">{question.question}</div>
        <div className="space-y-4">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              className={\`w-full text-left px-4 py-3 rounded-lg font-medium transition-colors
                \${isAnswered && index === question.correctIndex ? 'bg-green-500 text-white' : ''}
                \${isAnswered && index === selectedIndex && index !== question.correctIndex ? 'bg-red-500 text-white' : ''}
                \${!isAnswered ? 'bg-yellow-400 text-black hover:bg-yellow-300' : ''}\`}
              disabled={isAnswered}
            >
              {index + 1}. {option}
            </button>
          ))}
        </div>
        {isAnswered && (
          <div className="mt-6 text-green-300">
            <strong>{selectedIndex === question.correctIndex ? text.correct : text.incorrect}:</strong> {question.explanation}
          </div>
        )}
        {isAnswered && currentQuestionIndex < questions[language].length - 1 && (
          <button
            onClick={nextQuestion}
            className="mt-6 bg-yellow-400 text-black px-4 py-2 rounded hover:bg-yellow-300"
          >
            {text.next}
          </button>
        )}
      </div>
    </div>
  );
}
